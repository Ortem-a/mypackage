


#df = matrix(c(1,2,3,4,5,6,7,8,9,0,1,2), ncol = 4, nrow = 3)
#df = as.data.frame(matrix(c(1,2,3,4,5,6,7,8,9,0,1,2), ncol = 4, nrow = 3))
#df = data.frame(c(1,2,3,4,5,6,7,8,9,0,1,2))


library(docstring)

